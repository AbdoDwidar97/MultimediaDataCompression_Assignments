public class Tag {
    int Index;
    int Length;
    char Next;
}
