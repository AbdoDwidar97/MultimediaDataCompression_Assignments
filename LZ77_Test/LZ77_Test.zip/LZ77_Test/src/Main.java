public class Main {
    public static void main(String[] args){

        String Data = "AABABBBABAAABABAABBAABAA";
        String Data2 = "ERRMNERMMNNRREMRENNR";
        String Data3 = "ABCAABCBCBABBBCABCCBAB";

        Compression com = new Compression();
        com.Compress(Data);
        String Decom =  com.Decompress();
        System.out.println(Decom.equals(Data));

        // com.ShowMyTagsDetails();


        //int count = com.CountOfTags();
        //System.out.println(count);


    }
}
